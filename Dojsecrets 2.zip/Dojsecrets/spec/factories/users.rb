FactoryGirl.define do
  factory :user do
    name "amie"
    email "amieh456@gmail.com"
    password "password"
    password_confirmation "password"
  end
end
