Rails.application.routes.draw do
  # resources :sessions, only: [:new, :create, :destroy]
  # resources :users, only: [:show]

   get 'users/new' => 'users#new'

  get 'users/show'

  get 'users/edit'

  get 'users/:id' => 'users#show'

  get 'sessions/new' => 'sessions#new'



  post '/sessions' => 'sessions#create'
  delete '/sessions/:id' => 'sessions#destroy'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
