class DojosController < ApplicationController
  def index
      @dojos = Dojo.all
      @count = Dojo.count
  end

  def new
     @dojo = Dojo.new()


  end

  def edit
  end

  def create
      @dojo = Dojo.new(dojo_params)
      if @dojo.save
          redirect_to :root, notice: "You have successfully created a Dojo!"
      else
          flash[:errors] = @dojo.errors.full_messages
          redirect_to '/dojos/new'
      end

  end

  def update
  end

  def delete
  end

  def show
  end

  private
    def dojo_params
      params.require(:dojo).permit(:brach, :street, :city, :state)
    end
end
