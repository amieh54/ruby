require 'rails_helper'
feature "User creates an account" do
  before(:each) do
    visit "/users/new"
  end

scenario "successfully creates a new user account" do
    fill_in "username", with: "shane33"
    click_button "Sign In"
    expect(page).to have_content "Welcome shane33!"
    # We'll be redirecting to the user show page is user succesfully created
    expect(page).to have_current_path("/users/1")
  end


  scenario "unsuccessfully creates a new user account" do
      click_button "Sign In"
      expect(page).to have_content "Username"
      expect(current_path).to eq("/users/new")
  end
  scenario "doesn't fill out username field" do
      click_button "Sign In"
      expect(page).to have_content "Username can't be blank"
      expect(current_path).to eq('/users/new')
  end


end
#

#
# If created succesfully
# Current path should equal messages_path (messages#index) Current page should contain message you just created
#  If not created succesfully
# Current path should equal messages_path (messages#index) Current page should contain error messages (create test for each error except user reference required).
# end
