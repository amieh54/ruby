FactoryGirl.define do
  factory :message do
    content "MyStringppp"
    user nil 
  end
end
