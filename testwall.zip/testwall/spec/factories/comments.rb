FactoryGirl.define do
  factory :comment do
    content "MyStringppp"
    user nil
    message nil
  end
end
