FactoryGirl.define do
  factory :user do
    username "james22"
  end 
end
