Rails.application.routes.draw do
    root 'dojos#index'
    get 'dojos/new'
end
