class DojosController < ApplicationController
  def index
      @dojos = Dojo.all
      @count = Dojo.count
  end

  def new
  end

  def edit
  end

  def create
  end

  def update
  end

  def delete
  end

  def show
  end
end
