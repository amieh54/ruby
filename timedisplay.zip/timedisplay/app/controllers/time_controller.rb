class TimeController < ApplicationController
  def method
  end

  def main
      @time = Time.new
  end

end
