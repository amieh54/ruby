FactoryGirl.define do
  factory :user do
    name "Amie"
    email "amieh54@gmail.com"
    password "password"
    password_confirmation "password"
  end
end
