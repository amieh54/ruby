class UserController < ApplicationController
  def index
      render 'index.html.erb'
  end

  def new
  end

  def edit
  end
end
